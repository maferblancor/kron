@extends('layouts.app')

@section('content')

      <div class=" py-5 container" align="center"> 
        <h1>Some user Landing Page</h1>
    </div>

@endsection
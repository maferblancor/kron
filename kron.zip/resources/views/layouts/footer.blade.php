
<footer style=" 

  ;
   bottom:0;
   width:100%;
   " > 
   <div class="padre container">
      <img class="center-block img-fluid d-block mx-auto" src="{{ asset('assets/kron/icon_.png') }}" width="70">
    </div> 
    <div class="padre container">
      <p> © Kron Exclusive Community </p>
    </div> 

    <div class="padre container" > 
    
      <div class="hijo row">
        
                
        
            <a href="http://www.instagram.com" target="_blanc">
              <img class="center-block img-fluid d-block mx-auto" src="//editor.alleanzacreativa.com/images/socialmedia/8instagram.png" width="30"> 
            </a>
        

      </div>
       <div class="hijo"> 
            <a href="http://www.youtube.com" target="_blanc" >
              <img class="center-block img-fluid d-block mx-auto" src="//editor.alleanzacreativa.com/images/socialmedia/8youtube.png" width="30"> 
            </a>
        </div>
       <div class="hijo"> 
        
        
            <a href="http://www.twitter.com/" target="_blanc">
              <img class="center-block img-fluid d-block mx-auto" src="//editor.alleanzacreativa.com/images/socialmedia/8twitter.png" width="30"> 
            </a>
        </div>
       <div class="hijo"> 

        
            <a href="http://www.facebook.com" target="_blanc">
              <img class="center-block img-fluid d-block mx-auto" src="//editor.alleanzacreativa.com/images/socialmedia/8facebook.png" width="30"> 
            </a>
        
      
    </div>
     </div>
  
</footer>

@extends('layouts.app')

@section('content')

		
		<div class=" py-5 container" align="center">
			<h1>Not finished yet!</h1>
		</div>
	

@endsection
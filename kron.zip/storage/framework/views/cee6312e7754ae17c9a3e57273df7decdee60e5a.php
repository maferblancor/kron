<?php $__env->startSection('content'); ?>
      <div class="py-5 form-container"  >
    <div class="container my-5" >
      <div class="row mx-auto">
        <div class="col-md-6" >
                    <form method="POST" class="" style="opacity: 0.9;" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group ">
                            <label for="name" ><?php echo e(__('Name')); ?></label>

                          
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                           
                        </div>

                        <div class="form-group ">
                            <label for="email" ><?php echo e(__('E-Mail Address')); ?></label>

                            
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>

                        <div class="form-group ">
                            <label for="birth_date" ><?php echo e(__('Birth date')); ?></label>

                            
                                <input id="birth_date" type="date" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="birth_date"  required>

                                <?php if($errors->has('birth_date')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('birth_date')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
                            
                        <div class="form-group ">
                            <label for="password" ><?php echo e(__('Password')); ?></label>

                            
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>

                        <div class="form-group ">
                            <label for="password-confirm" ><?php echo e(__('Confirm Password')); ?></label>

                            
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        
<br>
                        <div class="form-group ">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
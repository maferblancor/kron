<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- PAGE settings -->
  <link rel="icon" href="https://templates.pingendo.com/assets/Pingendo_favicon.ico">
  <title>Conference Elegant - Pingendo template</title>
  <meta name="description" content="Free Bootstrap 4 Pingendo Elegant template for unique events.">
  <meta name="keywords" content="Pingendo conference event elegant free template bootstrap 4">
  <!-- CSS dependencies -->
  <link rel="stylesheet" href="<?php echo e(asset('css/elegant.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <!-- Script: Make my navbar transparent when the document is scrolled to top -->
  
  <script src="<?php echo e(asset('js/navbar-ontop.js')); ?>"></script>
  <!-- Script: Animated entrance -->
  <script src="<?php echo e(asset('js/animate-in.js')); ?>"></script>

</head>

<body class="text-center">
  <!-- Navbar -->
  
  <!-- Cover -->
  <div class="d-flex align-items-center py-5 photo-overlay cover" style="background-image: url(<?php echo e(asset('assets/conference/cover.jpg')); ?>);">
    <div class="container">
      <div class="row">
        <div class="text-white p-5 bg-dark-opaque col-12 col-lg-8 mx-auto">
          <p class="">December 12-14, NYC </p>
          <a href="#register" class="btn btn-lg mt-4 btn-primary">Register now</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Intro -->
  
  <div class="py-5">
    <div class="container my-5">
      <div class="row mx-auto">
        <div class="col-md-12">
          <h1 class="mb-3">About the event</h1>
          <p class="">Three days immersion in the world of UX/UI prototyping. Meet the most important design influencer of the moment, assist to speeches given by worldwide known designers and much, much more. The unique possibility to enhance your professionality with the smallest effort.</p>
          <a href="#schedule" class="btn m-2 btn-outline-light">Schedule</a>
          <a class="btn btn-primary m-2" href="#register">Register</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Speakers -->
  <div class="" id="speakers">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <h1 class="mb-4">Speakers</h1>
        </div>
      </div>
      <div class="row">
        <div class="col-6 col-lg-4 bg-light animate-in-down">
          <a href="#">
            <img src="assets/conference/people_1.jpg" class="center-block img-fluid my-3 rounded-circle" width="300">
            <h3 class="mb-0"><b class="text-dark">Janet Jong</b></h3>
            <p class="text-muted">UI designer</p>
          </a>
        </div>
        <div class="col-6 col-lg-4 bg-info animate-in-down">
          <a href="#">
            <img src="assets/conference/people_2.jpg" class="center-block img-fluid my-3 rounded-circle" width="300">
            <h3 class="mb-0"><b>da Vinci brothers</b></h3>
            <p class="text-dark">UX/UI designer</p>
          </a>
        </div>
        <div class="col-6 col-lg-4 bg-secondary animate-in-down">
          <a href="#">
            <img src="assets/conference/people_3.jpg" class="center-block img-fluid my-3 rounded-circle" width="300">
            <h3 class="mb-0"><b>Michelle Philips</b></h3>
            <p class="text-white">UX designer</p>
          </a>
        </div>
        <div class="col-6 col-lg-4 animate-in-down">
          <a href="#">
            <img src="assets/conference/people_4.jpg" class="center-block img-fluid my-3 rounded-circle" width="300">
            <h3 class="mb-0"><b>Jason Wang</b></h3>
            <p class="text-muted">Front-end developer</p>
          </a>
        </div>
        <div class="col-6 col-lg-4 bg-primary animate-in-down">
          <a href="#">
            <img src="assets/conference/people_5.jpg" class="center-block img-fluid my-3 rounded-circle" width="300">
            <h3 class="mb-0"><b>Helen Morgan</b></h3>
            <p class="">Bootstrap evangelist</p>
          </a>
        </div>
        <div class="col-6 mask col-lg-4 bg-dark animate-in-down">
          <a href="#">
            <img src="assets/conference/people_6.jpg" class="center-block img-fluid my-3 rounded-circle" width="300">
            <h3 class="mb-0"><b>Ramiro Potter</b></h3>
            <p class="">Front-end developer</p>
          </a>
        </div>
      </div>
    </div>
  </div>
  <!-- Schedule -->
  <div class="py-5" id="schedule">
    <div class="container my-5 bg-primary animate-in-down">
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-white mt-4">Schedule</h1>
        </div>
      </div>
      <div class="row text-left">
        <div class="p-4 col-lg-4 col-md-6">
          <div class="card">
            <div class="card-block text-center card-primary p-2">
              <h2>Day 1</h2>
              <p class="lead">Prototype</p>
            </div>
            <ul class="list-group list-group-flush">
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;09:30-10:00 –&nbsp;<b>Welcome</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;10:00-12:00 –&nbsp;<b>Bootstrap for UX</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;12:00-13:00 –&nbsp;<b>Q&amp;A</b></li>
              <li class="list-group-item list-group-item-info"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;13:00-14:30 –&nbsp;<b>Lunch break</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;14:30-16:00 –&nbsp;<b>Best practices</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;16:00-18:00 –&nbsp;<b>Editing workshop</b></li>
            </ul>
          </div>
        </div>
        <div class="p-4 col-lg-4 col-md-6">
          <div class="card">
            <div class="card-block text-center card-primary p-2">
              <h2>Day 2</h2>
              <p class="lead">Design</p>
            </div>
            <ul class="list-group list-group-flush">
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;09:30-10:00 –&nbsp;<b>Guest speech</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;10:00-12:00 –&nbsp;<b>Mobile design</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;12:00-13:00 –&nbsp;<b>UI trends</b></li>
              <li class="list-group-item list-group-item-info"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;13:00-14:30 –&nbsp;<b>Lunch break</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;14:30-16:00 –&nbsp;<b>Discussion</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;16:00-18:00 –&nbsp;<b>Party!</b></li>
            </ul>
          </div>
        </div>
        <div class="p-4 col-lg-4">
          <div class="card">
            <div class="card-block text-center p-2">
              <h2>Day 3</h2>
              <p class="lead">Publish</p>
            </div>
            <ul class="list-group list-group-flush">
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;09:30-10:00 –&nbsp;<b>Intro to WBN</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;10:00-12:00 –&nbsp;<b>Publishing</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;12:00-13:00 –&nbsp;<b>Implementation</b></li>
              <li class="list-group-item list-group-item-info"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;13:00-14:30 –&nbsp;<b>Lunch break</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;14:30-16:00 –&nbsp;<b>Farewell</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;16:00-18:00 –&nbsp;<b>Party!</b></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Sponsor logos -->
  <div class="py-5 section">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="mb-4">Sponsors</h1>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3 col-6">
          <img class="center-block img-fluid d-block" src="assets/conference/logo_1.png"> </div>
        <div class="col-md-3 col-6">
          <img class="center-block img-fluid d-block" src="assets/conference/logo_4.png"> </div>
        <div class="col-md-3 col-6">
          <img class="center-block img-fluid d-block" src="assets/conference/logo_3.png"> </div>
        <div class="col-md-3 col-6">
          <img class="center-block img-fluid d-block" src="assets/conference/logo_2.png"> </div>
      </div>
    </div>
  </div>
  <!-- Call to action -->
  <div class="py-5 section" id="register">
    <div class="container py-5">
      <div class="row animate-in-down">
        <div class="col-md-8 text-md-left text-center">
          <h1 class="mb-3 text-white">Registrations are open</h1>
          <p>Pre-register to get a priority access to the event. Fares will be published later on.&nbsp; <br>Get the maximum from the lectures together with the possibility of joining exclusive side-events.</p>
        </div>
        <div class="col-md-4 align-self-center">
          <a href="#" class="btn btn-lg btn-primary my-3">Register now</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <footer class="text-md-left text-center p-4 text-light">
    <div class="container">
      <div class="row">
        <div class="my-3 col-lg-4 col-md-6">
          <h3>Conference Pingendo</h3>
          <p class="text-muted">December 12-14, 2017</p>
          <p class="my-4">
            <a href="https://goo.gl/maps/ayn28vkB5F92" target="blank" class="text-muted">Empire State building 350 5th Ave, <br>New York, NY 10118</a>
          </p>
          <a class="btn btn-primary" href="#">Register now</a>
        </div>
        <div class="my-3 col-lg-4 col-md-6">
          <h3>Contact us</h3>
          <form>
            <fieldset class="form-group my-3">
              <input type="email" class="form-control" id="Input Email" placeholder="Email"> </fieldset>
            <fieldset class="form-group my-3">
              <input type="message" class="form-control" id="Input Message" placeholder="Message"> </fieldset>
            <button type="submit" class="btn btn-outline-primary">Submit</button>
          </form>
        </div>
        <div class="col-lg-1"> </div>
        <div class="my-3 col-lg-3">
          <h3>Follow</h3>
          <a href="https://www.facebook.com" target="blank"><i class="fa fa-facebook-square text-muted fa-3x m-2"></i></a>
          <a href="https://www.instagram.com" target="blank"><i class="fa fa-3x fa-instagram text-muted m-2"></i></a>
          <a href="https://twitter.com" target="blank"><i class="fa fa-3x fa-twitter m-2 text-muted"></i></a>
          <a href="https://plus.google.com" target="blank"><i class="fa fa-3x fa-google-plus-official text-muted m-2"></i></a>
          <a href="https://pinterest.com" target="blank"><i class="fa fa-3x text-muted fa-pinterest-p m-2"></i></a>
          <a href="https://www.youtube.com" target="blank"><i class="fa fa-3x text-muted fa-youtube-play m-2"></i></a>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <p class="text-muted">© Copyright 2018 Pingendo - All rights reserved. </p>
        </div>
      </div>
    </div>
  </footer>
  <!-- JavaScript dependencies -->
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <!-- Script: Smooth scrolling between anchors in a same page -->
  <script src="js/smooth-scroll.js"></script>
</body>

</html>
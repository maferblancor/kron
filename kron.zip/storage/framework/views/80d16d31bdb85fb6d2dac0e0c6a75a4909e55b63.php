<?php $__env->startSection('content'); ?>
		<?php if(Auth::guard('admin')->check()): ?>

			<?php echo $__env->make('post.create', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php endif; ?>	
		
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="py-4">
		    <div class="container">
		      <div class="row">
		        <div class="col-md-12">
		          <div class="card">
		          <a  href="posts/<?php echo e($post->id); ?>"> 
		          	<?php if($post->images != NULL): ?>
		          		<img class="card-img-top" src="<?php echo e(asset($post->images)); ?>" alt="Card image cap">
		          	<?php else: ?>
		   	   			<?php if($post->video != NULL): ?>
		   	   			<div class='video-container'>
		   	   				
							<video width="100%" height="100%" poster="<?php echo e(asset('assets/images/layer.jpg')); ?>" controls>
							   <source src="<?php echo e($post->video); ?>" type="video/mp4">
							</video>
							
					    	
						</div>
					   	<?php endif; ?>

		          	<?php endif; ?>
		          	</a>
		            <div class="card-body" >
		              <h2 class="card-title"><?php echo e($post->title); ?></h2>
		              <p class="card-text"><?php echo e(substr($post->content, 0, 500)); ?>... <a  href="posts/<?php echo e($post->id); ?>">More</a> </p> 
		              <p class="card-text"><?php echo e($post->created_at->diffForHumans()); ?></p>
		            </div>
		          </div>
		        </div>
		      </div>

				      	
			    
			    <?php if(Auth::guard('admin')->check()): ?>
				
				<br>
				<div class="row" align="center">
					<div class="col-md-12">
						<a href="posts/<?php echo e($post->id); ?>/edit" class="btn m-2 btn-outline-light" '>Edit</a>

					
					
          			<a class="btn btn-primary m-2" href="">Delete</a>
					</div>		
				</div>
						
				<?php endif; ?>
			</div>


		</div>
	

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		

	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>


<div class="py-5" >
    <div class="container my-5">
      <div class="row mx-auto">
        <div class="col-md-12">
  <h1>Users Control Panel</h1>
  <p >Users membership admin controller</p>

 <div class="row">
    <div class="col-3">Name</div>
    <div class="col-3">Email</div>
    <div class="col-3">Expiry Date</div>
    <div class="col-3">Actual State</div>	
 </div>
 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="row">
    <div class="col-3"><?php echo e($user->name); ?></div>
    <div class="col-3"><?php echo e($user->email); ?></div>
    <div class="col-3"><?php echo e($user->expiry_date); ?></div>
    <div class="col-3"><?php echo e(\App\Http\Controllers\ControlPanelController::stateMapping($user->state)); ?></div>	
  </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
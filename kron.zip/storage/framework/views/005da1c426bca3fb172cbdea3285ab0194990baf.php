<?php $__env->startSection('content'); ?>

		<div class="py-5">
		    <div class="container">
		      <div class="row">
		        <div class="col-md-12">
		          <div class="card">
		          <div class="card-body" >	
		          <br>
		          <h1  class="card-title" align="center"><?php echo e($post->title); ?></h1> 
		          <br>
		          	<?php if($post->images != NULL): ?>
		          		<img class="card-img-top" src="<?php echo e($post->images); ?>" alt="Card image cap">
		          	<?php else: ?>
		   	   			<?php if($post->video != NULL): ?>
		   	   			
					    	<video width="100%" height="100%" poster="<?php echo e(asset('assets/images/layer.jpg')); ?>" controls>
							   <source src="<?php echo e($post->video); ?>" type="video/mp4">
							</video>
						
					   	<?php endif; ?>

		          	<?php endif; ?>
		     			<div class="card-body" >       
		              <p class="card-text"><?php echo e($post->content); ?> </p> 
		              </div>
		              <?php if($post->video != NULL and $post->images): ?>

					    	<video width="100%" height="100%" poster="<?php echo e(asset('assets/images/layer.jpg')); ?>" controls>
							   <source src="<?php echo e($post->video); ?>" type="video/mp4">
							</video>
						<?php endif; ?>
		            </div>
		          </div>
		        </div>


		        
		   	   			

			
		      </div>

				 		      	
			    
			    <br>
				<div class="row" align="center">
					<div class="col-md-12">
			    <?php if(Auth::guard('admin')->check()): ?>
				
				
					<a href="#schedule" class="btn m-2 btn-outline-light" '>Edit</a>
          			<a class="btn btn-primary m-2" href="#register">Delete</a>
					<a href="<?php echo e(route('posts.index')); ?>" class="btn m-2 btn-secondary" >Back</a>
				<?php else: ?>
					<a href="<?php echo e(route('user.posts.index')); ?>" class="btn m-2 btn-secondary" >Back</a>		
				<?php endif; ?>
				
					</div>		
			</div>
				
			</div>


		</div>
	

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
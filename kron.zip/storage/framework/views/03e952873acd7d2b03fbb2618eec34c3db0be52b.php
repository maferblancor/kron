<?php $__env->startSection('content'); ?>
  
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__env->startComponent('components.who'); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>

                 <div class="py-5" id="schedule" >
    <div class="container my-5 bg-primary animate-in-down">
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-white mt-4">Schedule</h1>
        </div>
      </div>
      <div class="row text-left">
        <div class="p-4 col-lg-4 col-md-6">
          <div class="card">
            <div class="card-block text-center card-primary p-2">
              <h2>Day 1</h2>
              <p class="lead">Prototype</p>
            </div>
            <ul class="list-group list-group-flush">
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;09:30-10:00 –&nbsp;<b>Welcome</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;10:00-12:00 –&nbsp;<b>Bootstrap for UX</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;12:00-13:00 –&nbsp;<b>Q&amp;A</b></li>
              <li class="list-group-item list-group-item-info"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;13:00-14:30 –&nbsp;<b>Lunch break</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;14:30-16:00 –&nbsp;<b>Best practices</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;16:00-18:00 –&nbsp;<b>Editing workshop</b></li>
            </ul>
          </div>
        </div>
        <div class="p-4 col-lg-4 col-md-6">
          <div class="card">
            <div class="card-block text-center card-primary p-2">
              <h2>Day 2</h2>
              <p class="lead">Design</p>
            </div>
            <ul class="list-group list-group-flush">
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;09:30-10:00 –&nbsp;<b>Guest speech</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;10:00-12:00 –&nbsp;<b>Mobile design</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;12:00-13:00 –&nbsp;<b>UI trends</b></li>
              <li class="list-group-item list-group-item-info"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;13:00-14:30 –&nbsp;<b>Lunch break</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;14:30-16:00 –&nbsp;<b>Discussion</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;16:00-18:00 –&nbsp;<b>Party!</b></li>
            </ul>
          </div>
        </div>
        <div class="p-4 col-lg-4">
          <div class="card">
            <div class="card-block text-center p-2">
              <h2>Day 3</h2>
              <p class="lead">Publish</p>
            </div>
            <ul class="list-group list-group-flush">
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;09:30-10:00 –&nbsp;<b>Intro to WBN</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;10:00-12:00 –&nbsp;<b>Publishing</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;12:00-13:00 –&nbsp;<b>Implementation</b></li>
              <li class="list-group-item list-group-item-info"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;13:00-14:30 –&nbsp;<b>Lunch break</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;14:30-16:00 –&nbsp;<b>Farewell</b></li>
              <li class="list-group-item"><i class="mx-auto fa d-inline fa-clock-o text-secondary"></i>&nbsp;16:00-18:00 –&nbsp;<b>Party!</b></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>